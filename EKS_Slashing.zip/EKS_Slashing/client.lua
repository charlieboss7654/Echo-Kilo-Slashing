Config = Config or {}

local function isHoldingSlashingWeapon()
    local weapon = GetSelectedPedWeapon(PlayerPedId())
    return Config.SlashingWeapons and Config.SlashingWeapons[weapon] == true
end

local function playSlashAnim()
    RequestAnimDict("melee@knife@streamed_core")
    while not HasAnimDictLoaded("melee@knife@streamed_core") do Wait(0) end
    TaskPlayAnim(PlayerPedId(), "melee@knife@streamed_core", "ground_attack_on_spot", 8.0, -8.0, 1000, 0, 0, false, false, false)
end

local function slashTyre(vehicle, tyreIndex)
    if IsVehicleTyreBurst(vehicle, tyreIndex, false) then return end
    local ped = PlayerPedId()
    TaskTurnPedToFaceEntity(ped, vehicle, 500)
    Wait(300)
    playSlashAnim()
    Wait(700)
    SetVehicleTyreBurst(vehicle, tyreIndex, false, 1000.0)
end

local tyreBones = {
    { name = "wheel_lf", index = 0 },
    { name = "wheel_rf", index = 1 },
    { name = "wheel_lm1", index = 2 },
    { name = "wheel_rm1", index = 3 },
    { name = "wheel_lr", index = 4 },
    { name = "wheel_rr", index = 5 },
    { name = "wheel_lm2", index = 45 },
    { name = "wheel_rm2", index = 47 },
    { name = "wheel_lm3", index = 48 },
    { name = "wheel_rm3", index = 49 }
}

local activeZones = {}

CreateThread(function()
    while true do
        Wait(1000)

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local vehicle = GetClosestVehicle(coords, 3.0, 0, 70)

        if vehicle ~= 0 and DoesEntityExist(vehicle) then
            for _, tyre in pairs(tyreBones) do
                local boneIndex = GetEntityBoneIndexByName(vehicle, tyre.name)

                if boneIndex ~= -1 then
                    local bonePos = GetWorldPositionOfEntityBone(vehicle, boneIndex)
                    local zoneName = "tyreslash_" .. tyre.name

                    if not activeZones[zoneName] then
                        exports.ox_target:addSphereZone({
                            name = zoneName,
                            coords = bonePos,
                            radius = 0.3,
                            debug = false,
                            distance = 1.2,
                            options = {
                                {
                                    label = "Slash Tyre",
                                    icon = "fas fa-scissors",
                                    onSelect = function()
                                        slashTyre(vehicle, tyre.index)
                                    end,
                                    canInteract = function()
                                        return isHoldingSlashingWeapon() and not IsVehicleTyreBurst(vehicle, tyre.index, false)
                                    end
                                }
                            }
                        })
                        activeZones[zoneName] = true
                    end
                end
            end
        else
            for name, _ in pairs(activeZones) do
                exports.ox_target:removeZone(name)
            end
            activeZones = {}
        end
    end
end)
