Config = {}

Config.SlashingWeapons = {
    [GetHashKey('WEAPON_KNIFE')] = true,
    [GetHashKey('WEAPON_SWITCHBLADE')] = true,
    [GetHashKey('WEAPON_DAGGER')] = true,
    [GetHashKey('WEAPON_MACHETE')] = true
}
