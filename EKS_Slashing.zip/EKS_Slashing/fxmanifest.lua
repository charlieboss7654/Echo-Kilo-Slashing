fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Tyre Slashing Script with configurable weapons and natural deflation'

client_scripts {
    'config.lua',
    'client.lua'
}

dependencies {
    'ox_target'
}
